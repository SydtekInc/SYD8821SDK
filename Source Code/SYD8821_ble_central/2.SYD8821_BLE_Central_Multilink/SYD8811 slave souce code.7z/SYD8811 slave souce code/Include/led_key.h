#ifndef _KEY_H_
#define _KEY_H_

#include "ARMCM0.h"

#define KEY1 GPIO_20
#define KEY2 GPIO_22
#define KEY3 GPIO_23
#define KEY4 GPIO_24

#define LED1 GPIO_0
#define LED2 GPIO_1
#define LED3 GPIO_21
#define LED4 GPIO_5
#endif

#ifndef _DELAY__H__
#define _DELAY__H__

#include "ARMCM0.h"

void delay_ms(uint16_t n);
void delay_us(uint16_t n);

#endif
